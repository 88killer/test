const quizContainer = document.getElementById('quizContainer');
const resultContainer = document.getElementById('resultContainer');
const questionElement = document.getElementById('question');
const optionsElement = document.getElementById('options');
const submitBtn = document.getElementById('submitBtn');
const progressElement = document.getElementById('progress');
const feedbackElement = document.getElementById('feedback');
const timerElement = document.getElementById('timer');
const resultElement = document.getElementById('result');
const resultTitle = document.getElementById('resultTitle');
const restartBtn = document.getElementById('restartBtn');
const correctSound = document.getElementById('correctSound');
const wrongSound = document.getElementById('wrongSound');
const switchLanguageBtn = document.getElementById('switchLanguage');
const titleElement = document.getElementById('title');

let selectedOption = null;
let currentQuestionIndex = 0;
let correctAnswers = 0;
let totalTime = 0;
let timer;
let isEnglish = false;

const questions = [
    {
        category: "前端",
        question: "以下哪个是JavaScript框架？",
        options: ["React", "Python", "Java", "C++"],
        answer: 0
    },
    {
        category: "前端",
        question: "HTML是什么的缩写？",
        options: ["HyperText Markup Language", "High-Level Text Language", "Hyperlink and Text Markup Language", "Home Tool Markup Language"],
        answer: 0
    },
    {
        category: "前端",
        question: "CSS用于什么？",
        options: ["网页结构", "网页样式", "网页逻辑", "网页数据"],
        answer: 1
    },
    {
        category: "后端",
        question: "以下哪个是数据库？",
        options: ["MySQL", "HTML", "CSS", "JavaScript"],
        answer: 0
    }
];

const translations = {
    zh: {
        title: "答题界面",
        timer: "剩余时间：",
        submit: "提交",
        correct: "回答正确！",
        wrong: "回答错误！",
        end: "答题结束！",
        resultTitle: "答题结果",
        result: "总答题时间：{time} 秒，准确率：{accuracy}%",
        restart: "重新开始",
        switchLanguage: "切换语言/Change Language"
    },
    en: {
        title: "Quiz Interface",
        timer: "Time Left: ",
        submit: "Submit",
        correct: "Correct!",
        wrong: "Wrong!",
        end: "Quiz Over!",
        resultTitle: "Quiz Result",
        result: "Total Time: {time} seconds, Accuracy: {accuracy}%",
        restart: "Restart",
        switchLanguage: "切换语言/Change Language"
    }
};

function loadQuestion() {
    const question = questions[currentQuestionIndex];
    questionElement.textContent = question.question;
    optionsElement.innerHTML = question.options.map((option, index) => `
        <div class="option" data-index="${index}">${option}</div>
    `).join('');
    selectedOption = null;
    submitBtn.disabled = true;
    updateProgress();
    startTimer();
}

function updateProgress() {
    const progress = ((currentQuestionIndex + 1) / questions.length) * 100;
    progressElement.style.width = `${progress}%`;
}

function showFeedback(message, isError) {
    feedbackElement.textContent = message;
    feedbackElement.classList.toggle('error', isError);
    feedbackElement.classList.add('show');
    setTimeout(() => {
        feedbackElement.classList.remove('show');
    }, 2000);
}

function startTimer() {
    let timeLeft = 30;
    timer = setInterval(() => {
        timeLeft--;
        timerElement.textContent = `${isEnglish ? translations.en.timer : translations.zh.timer}${timeLeft} 秒`;
        if (timeLeft <= 0) {
            clearInterval(timer);
            submitAnswer();
        }
    }, 1000);
}

function submitAnswer() {
    clearInterval(timer);
    totalTime += (30 - parseInt(timerElement.textContent.match(/\d+/)[0]));
    if (selectedOption == questions[currentQuestionIndex].answer) {
        correctAnswers++;
        showFeedback(isEnglish ? translations.en.correct : translations.zh.correct, false);
        correctSound.play();
    } else {
        showFeedback(isEnglish ? translations.en.wrong : translations.zh.wrong, true);
        wrongSound.play();
    }
    currentQuestionIndex++;
    if (currentQuestionIndex < questions.length) {
        loadQuestion();
    } else {
        showResult();
    }
}

function showResult() {
    const accuracy = ((correctAnswers / questions.length) * 100).toFixed(2);
    resultElement.textContent = isEnglish
        ? translations.en.result.replace("{time}", totalTime).replace("{accuracy}", accuracy)
        : translations.zh.result.replace("{time}", totalTime).replace("{accuracy}", accuracy);
    resultTitle.textContent = isEnglish ? translations.en.resultTitle : translations.zh.resultTitle;
    restartBtn.textContent = isEnglish ? translations.en.restart : translations.zh.restart;

    // 隐藏答题界面，显示结果界面
    quizContainer.style.display = "none";
    resultContainer.style.display = "block";
}

function restartQuiz() {
    currentQuestionIndex = 0;
    correctAnswers = 0;
    totalTime = 0;
    quizContainer.style.display = "block";
    resultContainer.style.display = "none";
    loadQuestion();
}

function switchLanguage() {
    isEnglish = !isEnglish;
    titleElement.textContent = isEnglish ? translations.en.title : translations.zh.title;
    submitBtn.textContent = isEnglish ? translations.en.submit : translations.zh.submit;
    switchLanguageBtn.textContent = isEnglish ? translations.en.switchLanguage : translations.zh.switchLanguage;
    if (currentQuestionIndex >= questions.length) {
        showResult();
    }
}

optionsElement.addEventListener('click', (e) => {
    if (e.target.classList.contains('option')) {
        if (selectedOption !== null) {
            optionsElement.children[selectedOption].classList.remove('selected');
        }
        selectedOption = e.target.dataset.index;
        e.target.classList.add('selected');
        submitBtn.disabled = false;
    }
});

submitBtn.addEventListener('click', submitAnswer);
switchLanguageBtn.addEventListener('click', switchLanguage);
restartBtn.addEventListener('click', restartQuiz);

loadQuestion();