const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bodyParser = require('body-parser');
const path = require('path');
const WebSocket = require('ws'); // 使用 WebSocket 客户端库
const crypto = require('crypto'); // 用于生成签名

const app = express();
const db = new sqlite3.Database('./database.db');

// 使用 body-parser 解析 JSON 请求体
app.use(bodyParser.json());

// 设置静态文件目录
app.use(express.static(path.join(__dirname, 'public')));

// 创建用户表
db.serialize(() => {
    db.run(`
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE,
            password TEXT
        )
    `);
});

// 注册接口
app.post('/register', (req, res) => {
    const { username, password } = req.body;

    // 检查用户名是否已存在
    db.get('SELECT * FROM users WHERE username = ?', [username], (err, row) => {
        if (err) {
            return res.status(500).json({ success: false, message: '数据库错误' });
        }

        if (row) {
            return res.json({ success: false, message: '用户名已存在' });
        }

        // 插入新用户
        db.run('INSERT INTO users (username, password) VALUES (?, ?)', [username, password], function (err) {
            if (err) {
                return res.status(500).json({ success: false, message: '注册失败' });
            }

            res.json({ success: true, message: '注册成功' });
        });
    });
});

// 登录接口
app.post('/login', (req, res) => {
    const { username, password } = req.body;

    // 检查用户名和密码是否匹配
    db.get('SELECT * FROM users WHERE username = ? AND password = ?', [username, password], (err, row) => {
        if (err) {
            return res.status(500).json({ success: false, message: '数据库错误' });
        }

        if (!row) {
            return res.json({ success: false, message: '用户名或密码错误' });
        }

        res.json({ success: true, message: '登录成功' });
    });
});

// 生成签名的函数
function generateSignature(apiKey, apiSecret, timestamp) {
    const data = `${apiKey}${timestamp}${apiSecret}`;
    return crypto.createHash('sha256').update(data).digest('hex');
}

// AI 接口
app.post('/ai', async (req, res) => {
    const { question } = req.body;

    const apiKey = '2d2e21aa4146450728e9d6f66e84209a'; // 替换为你的API Key
    const apiSecret = 'NzUwZGJlYzI3NGNmOTIwNGM5NGMzNDdi'; // 替换为你的API Secret
    const timestamp = Date.now(); // 当前时间戳
    const signature = generateSignature(apiKey, apiSecret, timestamp);

    try {
        // 连接到星火大模型的 WebSocket
        const ws = new WebSocket('wss://spark-api.xf-yun.com/v3.5/chat', {
            headers: {
                'api_key': apiKey,
                'timestamp': timestamp,
                'signature': signature,
            },
        });

        ws.on('open', () => {
            // 发送消息给星火大模型
            ws.send(JSON.stringify({
                question: question,
            }));
        });

        ws.on('message', (data) => {
            const response = JSON.parse(data);
            res.json({ answer: response.answer }); // 返回 AI 的回答
            ws.close();
        });

        ws.on('error', (error) => {
            console.error('WebSocket 错误:', error);
            res.status(500).json({ answer: '抱歉，AI助手暂时无法回答你的问题。' });
        });
    } catch (error) {
        console.error('Error calling AI API:', error);
        res.status(500).json({ answer: '抱歉，AI助手暂时无法回答你的问题。' });
    }
});

// 首页路由（登录页面）
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

// 答题页面路由
app.get('/quiz', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'quiz.html'));
});

// 启动服务器
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`服务器运行在 http://localhost:${PORT}`);
});